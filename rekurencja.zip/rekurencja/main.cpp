#include <iostream>

using namespace std;
long long silnia_iter(int licz)
{
    if(licz==0) return 1;
else return licz*silnia_iter(licz-1);
}
long long silnia_rek(int licz)
{
    long long wynik=1;
    if(licz>1)
        for(int i=2; i<=licz; i++)
        wynik = wynik * i;
    return wynik;
}
int main()
{
    cout << "obliczanie silni" << endl;
    cout << "podaj liczbe:";
    int liczba;
    cin >> liczba;
    cout << "silnia(T) wynosi: " <<silnia_iter(liczba) << endl;
    cout << "silnia(R) wynosi: " <<silnia_rek(liczba);
    return 0;
}

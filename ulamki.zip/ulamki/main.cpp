#include <iostream>

using namespace std;

struct ulamki{
int licznik;
int mianownik;
};
int NWD(int a, int b)
{
    int pom;
	while(b!=0)
    {
		pom = b;
		b = a%b;
		a = pom;
	}
    return a;
}
ulamki skroc(ulamki a)
{
    ulamki wynik = a;
    int nwd_ulamka = NWD(a.licznik, a.mianownik);
    wynik.licznik /= nwd_ulamka;
    wynik.mianownik /= nwd_ulamka;
    return wynik;
}
ulamki mnozenie(ulamki u1, ulamki u2)
{
    ulamki wynik;
    wynik.licznik = u1.licznik * u2.licznik;
    wynik.mianownik = u1.mianownik * u2.mianownik;
    return skroc(wynik);

}
ulamki dzielenie(ulamki u1, ulamki u2)
{
    ulamki wynik;
    wynik.licznik = u1.licznik * u2.mianownik;
    wynik.mianownik = u1.mianownik * u2.licznik;
    return skroc(wynik);
}
ulamki dodawanie(ulamki u1, ulamki u2)
{
    ulamki wynik;
    wynik.licznik = u1.licznik * u2.mianownik + u2.licznik * u1.mianownik;
    wynik.mianownik = u1.mianownik * u2.mianownik;
    return skroc(wynik);
}
ulamki odejmowanie(ulamki u1, ulamki u2)
{
    ulamki wynik;
    wynik.licznik = u1.licznik * u2.mianownik - u2.licznik * u1.mianownik;
    wynik.mianownik = u1.mianownik * u2.mianownik;
    return skroc(wynik);
}
int main()
{
    ulamki u1, u2, wynik;
    int wybierz;
    char koniec='n', dane='n';


do{
if((dane == 'n')||(dane == 'N'))
{
    cout << "Podaj pierwszy licznik: ";
    cin  >> u1.licznik;
    cout << "Podaj pierwszy mianownik: ";
    cin  >> u1.mianownik;
    cout << "Podaj drugi licznik: ";
    cin  >> u2.licznik;
    cout << "Podaj drugi mianownik: ";
    cin  >> u2.mianownik;
    }
    cout<< "wybierz jakie dzialanie chcesz wykonac" << endl;
    cout<< "1 - dla dodawania" << endl;
    cout<< "2 - dla odejmowania" << endl;
    cout<< "3 - dla mnozenia" << endl;
    cout<< "4 - dla dzielenia" << endl;
    cin >> wybierz;
    switch(wybierz)
    {

        case 1:
    wynik = dodawanie(u1, u2);
    cout << "dodawanie wynosi: "<< wynik.licznik << "/" << wynik.mianownik <<endl;
    break;

        case 2:
    wynik = odejmowanie(u1, u2);
    cout << "odejmowanie wynosi: "<< wynik.licznik << "/" << wynik.mianownik <<endl;
    break;

        case 3:
    wynik = mnozenie(u1, u2);
    cout << "mnozenie wynosi: "<< wynik.licznik << "/" << wynik.mianownik <<endl;
    break;

        case 4:
    wynik = dzielenie(u1, u2);
    cout << "dzielenie wynosi: "<< wynik.licznik << "/" << wynik.mianownik <<endl;
    break;}

    cout << "chcesz kontynuowac?\nY/N: ";
    cin >> koniec;

 if((koniec == 'y')||(koniec == 'Y'))
 {
     cout << "chcesz kontynuowac z tymi samymi danymi?\nY/N: ";
     cin>> dane;
 }
}while((koniec == 'y')||(koniec == 'Y'));
return 0;}

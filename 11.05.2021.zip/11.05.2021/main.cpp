#include <iostream>

using namespace std;

int main()
{
     // char znaki[6] = {'a','b','c','d','e','\0'};
    // cout << znaki <<endl;
   //  for(int i=5; i>=0; i--)cout <<znaki[i];


     cout << "teksty" <<endl;
     string napis="Witaj"; //255 znakow
     string nazwisko;
     cout<< "Podaj nazwisko:";
     cin>> nazwisko;
     cout <<napis+' '+nazwisko;








    return 0;
}

#include <iostream>
#include <string>
using namespace std;
bool teksty_sa_identyczne(string t1,string t2)
{
    int i, dl1,dl2;
    i = 0;
    dl1 = t1.length();
    dl2 = t2.length();
    while (i < dl1 && i < dl2 && t1[i] == t2[i])
    i++;
    return i == dl1 && i==dl2;
}

int main()
{
    string tekst1, tekst2;
    cout << "wpisz pierwzszy tekst:";
    getline(cin,tekst1);
    cout << "wpisz drugi tekst:";
    getline(cin,tekst2);
    if(teksty_sa_identyczne(tekst1,tekst2))
    cout <<"teksty sa takie same";
    else cout << "teksty nie sa takie same";
    return 0;
}

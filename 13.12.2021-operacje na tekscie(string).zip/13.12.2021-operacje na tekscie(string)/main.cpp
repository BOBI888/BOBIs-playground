#include <iostream>
#include <string>
using namespace std;

int main()
{
    string imie, nazwisko;
    cout << "napisz swoje imie:";
    cin >>imie;
    cout <<endl<<" napisz swoje nazwisko:";
    cin>>nazwisko;
    cout <<endl<<imie[0]<<"."<<nazwisko[0]<<"."<<endl;
    cout <<imie[imie.length()-1];
    cout <<nazwisko[nazwisko.length()-1];
    if(imie[imie.length()-1]=='a')cout <<endl<<"K"<<endl<<endl;
    else cout<<endl<<"M"<<endl<<endl;
    for(int i=0;i<=imie.length()-1;i++)
    {
        cout <<imie[i]<<endl;
    }
    cout<<endl;
    for(int i=0;i<=nazwisko.length()-1;i++)
    {
        cout <<nazwisko[i]<<endl;
    }






    return 0;
}

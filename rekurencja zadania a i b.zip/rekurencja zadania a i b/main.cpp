#include <iostream>

using namespace std;

float ciag_a(int n)
{
    if(n==1) return 2;
    else return 3*ciag_a(n-1)+0.5;
}

float ciag_b(int n)
{
    if(n==1) return 1;
    else if (n==2) return -4;
    else return ciag_b(n-2)+2*ciag_b(n-1)+0.5;
}

int main()
{
    for(int i=1; i<=5; i++) cout << ciag_a(i) << endl;
    for(int i=1; i<=5; i++) cout << ciag_b(i) << endl;
    return 0;
}

#include <iostream>

using namespace std;

int main()
{
    cout << " program do przeliczania z jednego dowolnego sysytemu na dowolny inny system" << endl;
    int potega, dziesietna, p1, p2;
    string liczba;
    cout << "podaj numer podstawy systemu w jakim bedzie liczba: ";
    cin >> p1;
    cout << "\npodaj numer podstawy systemu na jaki chcesz przeliczyc: ";
    cin >> p2;
    cout << "\npodaj liczbe do przeliczenia: ";
    cin >> liczba;
    potega=1;
    dziesietna=0;
    for (int i=liczba.length()-1; i>=0; i--)
    {
        if(liczba[i]>='0' && liczba[i]<='9')
        dziesietna +=(liczba[i]-'0')*potega;

        else
        dziesietna +=(liczba[i]-'A' + 10)*potega;
        potega*=p1;
    }
    string wynik = "";
    do {
        wynik = (char)(dziesietna % p2 + '0') + wynik;
        dziesietna /= p2;
    }while (dziesietna > 0);
    cout <<"\nliczba wyjsciowa to: "<<wynik;
    return 0;
}

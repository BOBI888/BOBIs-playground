#include <iostream>

using namespace std;

long long ciagF(int n)
{
    if(n<3) return 1;
    else
        return ciagF(n-1) + ciagF(n-2);
}


int main()
{
    cout << "podaj n" << endl;
    int n;
    cin >> n;
    cout << ciagF(n);
    return 0;
}
